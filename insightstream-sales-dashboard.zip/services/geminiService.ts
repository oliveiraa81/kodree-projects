import { GoogleGenAI } from "@google/genai";
import { AggregatedStats } from "../types";

const SYSTEM_INSTRUCTION = `
You are a senior Data Analyst writing an Executive Summary for a Sales Director.
Your goal is to be concise, professional, and insight-driven.
Focus on:
1. High-level performance (Revenue, Growth).
2. Outliers (Best regions, worst performers).
3. Strategic recommendations based on the data provided.

Do not mention "JSON" or "Data Source". Write it as a business report.
Use bullet points for readability.
Keep it under 250 words.
`;

export const generateExecutiveSummary = async (stats: AggregatedStats): Promise<string> => {
  if (!process.env.API_KEY) {
    return "Error: API Key is missing. Please ensure REACT_APP_GEMINI_API_KEY is set in your environment.";
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  // We only send aggregated data to protect privacy of individual rows
  const safePayload = {
    totalRevenue: stats.totalRevenue,
    avgDealSize: stats.avgDealSize,
    totalOrders: stats.totalOrders,
    topRegions: stats.revenueByRegion.slice(0, 3),
    underperformingRegions: stats.revenueByRegion.slice(-3),
    topProducts: stats.topSubcategories.slice(0, 3),
    topSalesReps: stats.salesRepPerformance.slice(0, 3),
    lowSalesReps: stats.salesRepPerformance.slice(-3),
  };

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Analyze the following sales data structure and provide an executive summary:\n\n${JSON.stringify(safePayload, null, 2)}`,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.2, // Low temperature for factual reporting
      },
    });

    return response.text || "Could not generate summary.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Unable to generate executive summary at this time. Please check your network connection or API quota.";
  }
};