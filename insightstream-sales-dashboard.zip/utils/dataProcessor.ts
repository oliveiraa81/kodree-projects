import * as XLSX from 'xlsx';
import { SalesRecord, AggregatedStats } from '../types';
import { parseISO, format, isValid } from 'date-fns';

export const parseFile = async (file: File): Promise<SalesRecord[]> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = e.target?.result;
        const workbook = XLSX.read(data, { type: 'binary', cellDates: true });
        const sheetName = workbook.SheetNames[0];
        const sheet = workbook.Sheets[sheetName];
        const rawJson = XLSX.utils.sheet_to_json(sheet) as any[];

        const parsedData: SalesRecord[] = rawJson.map((row) => {
          // Normalize keys to lowercase to match requirements
          const normalized: any = {};
          Object.keys(row).forEach((key) => {
            normalized[key.toLowerCase().trim()] = row[key];
          });

          const quantity = Number(normalized.quantity) || 0;
          const unitprice = Number(normalized.unitprice) || 0;
          const discount = Number(normalized.discount) || 0;
          
          // Calculate Revenue: Qty * Price * (1 - Discount%)
          // Assuming discount is 0.0-1.0. If > 1, treating as absolute amount off per unit? 
          // For safety, let's assume if discount < 1 it's percentage, else absolute.
          let finalPrice = unitprice;
          if (discount > 0 && discount <= 1) {
            finalPrice = unitprice * (1 - discount);
          } else if (discount > 1) {
            finalPrice = Math.max(0, unitprice - discount);
          }

          const revenue = quantity * finalPrice;

          // Attempt to parse date
          let date = new Date();
          if (normalized.invoicedate instanceof Date) {
            date = normalized.invoicedate;
          } else if (typeof normalized.invoicedate === 'string') {
            const parsed = parseISO(normalized.invoicedate);
            if (isValid(parsed)) date = parsed;
          }

          return {
            stockcode: normalized.stockcode || 'Unknown',
            subcategory: normalized.subcategory || 'Other',
            quantity,
            invoicedate: date,
            unitprice,
            customerid: normalized.customerid || 'Guest',
            discount,
            paymentmethod: normalized.paymentmethod || 'Unknown',
            shippingcost: Number(normalized.shippingcost) || 0,
            category: normalized.category || 'Uncategorized',
            returnstatus: normalized.returnstatus || 'None',
            shipmentprovider: normalized.shipmentprovider || 'Standard',
            orderpriority: normalized.orderpriority || 'Medium',
            revenue,
            // Try to map Region/Rep if they exist, otherwise derived or undefined
            region: normalized.region || normalized.country || 'Global',
            salesrep: normalized.salesrep || normalized['sales rep'] || 'Direct Sales',
          };
        });

        resolve(parsedData);
      } catch (error) {
        reject(error);
      }
    };
    reader.readAsBinaryString(file);
  });
};

export const aggregateData = (data: SalesRecord[]): AggregatedStats => {
  const stats: AggregatedStats = {
    totalRevenue: 0,
    totalOrders: data.length,
    avgDealSize: 0,
    totalDiscountGiven: 0,
    topCategories: [],
    topSubcategories: [],
    revenueByRegion: [],
    revenueByDate: [],
    salesRepPerformance: [],
    paymentMethods: [],
    orderPriorityDist: [],
  };

  const catMap = new Map<string, number>();
  const subCatMap = new Map<string, number>();
  const regionMap = new Map<string, number>();
  const dateMap = new Map<string, number>();
  const repMap = new Map<string, { revenue: number; deals: number }>();
  const paymentMap = new Map<string, number>();
  const priorityMap = new Map<string, number>();

  data.forEach((row) => {
    // Only count non-returned items for revenue? 
    // Usually sales dashboards show Gross Revenue unless specified Net.
    // We will exclude 'Returned' status from revenue if strictly analysis, 
    // but for simplicity we'll just sum all invoiced amounts unless status is explicitly 'Returned'.
    if (row.returnstatus?.toLowerCase() === 'returned') return;

    stats.totalRevenue += row.revenue;

    // Categories
    catMap.set(row.category, (catMap.get(row.category) || 0) + row.revenue);
    
    // Subcategories
    subCatMap.set(row.subcategory, (subCatMap.get(row.subcategory) || 0) + row.revenue);

    // Regions
    const region = row.region || 'Unknown';
    regionMap.set(region, (regionMap.get(region) || 0) + row.revenue);

    // Sales Reps
    const rep = row.salesrep || 'Unassigned';
    const repData = repMap.get(rep) || { revenue: 0, deals: 0 };
    repData.revenue += row.revenue;
    repData.deals += 1;
    repMap.set(rep, repData);

    // Date
    if (isValid(row.invoicedate)) {
      const dateKey = format(row.invoicedate as Date, 'yyyy-MM-dd');
      dateMap.set(dateKey, (dateMap.get(dateKey) || 0) + row.revenue);
    }

    // Payment
    paymentMap.set(row.paymentmethod, (paymentMap.get(row.paymentmethod) || 0) + 1); // Count of orders

    // Priority
    priorityMap.set(row.orderpriority, (priorityMap.get(row.orderpriority) || 0) + 1);
  });

  stats.avgDealSize = stats.totalOrders > 0 ? stats.totalRevenue / stats.totalOrders : 0;

  // Transform Maps to Arrays and Sort
  stats.topCategories = Array.from(catMap, ([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);
  stats.topSubcategories = Array.from(subCatMap, ([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value).slice(0, 10);
  stats.revenueByRegion = Array.from(regionMap, ([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);
  stats.salesRepPerformance = Array.from(repMap, ([name, data]) => ({ name, ...data })).sort((a, b) => b.revenue - a.revenue);
  
  // Sort dates
  stats.revenueByDate = Array.from(dateMap, ([date, value]) => ({ date, value })).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  stats.paymentMethods = Array.from(paymentMap, ([name, value]) => ({ name, value }));
  stats.orderPriorityDist = Array.from(priorityMap, ([name, value]) => ({ name, value }));

  return stats;
};