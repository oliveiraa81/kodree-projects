export interface SalesRecord {
  stockcode: string;
  subcategory: string;
  quantity: number;
  invoicedate: string | Date;
  unitprice: number;
  customerid: string;
  discount: number;
  paymentmethod: string;
  shippingcost: number;
  category: string;
  returnstatus: string;
  shipmentprovider: string;
  orderpriority: string;
  // Optional derived fields
  region?: string; 
  salesrep?: string;
  revenue: number;
}

export interface AggregatedStats {
  totalRevenue: number;
  totalOrders: number;
  avgDealSize: number;
  totalDiscountGiven: number;
  topCategories: { name: string; value: number }[];
  topSubcategories: { name: string; value: number }[];
  revenueByRegion: { name: string; value: number }[];
  revenueByDate: { date: string; value: number }[];
  salesRepPerformance: { name: string; revenue: number; deals: number }[];
  paymentMethods: { name: string; value: number }[];
  orderPriorityDist: { name: string; value: number }[];
}

export type MetricType = 'revenue' | 'orders' | 'avgValue';