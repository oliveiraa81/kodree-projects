import React, { useState } from 'react';
import FileUpload from './components/FileUpload';
import Dashboard from './components/Dashboard';
import { parseFile, aggregateData } from './utils/dataProcessor';
import { SalesRecord, AggregatedStats } from './types';
import { LayoutDashboard } from 'lucide-react';

const App: React.FC = () => {
  const [data, setData] = useState<SalesRecord[] | null>(null);
  const [stats, setStats] = useState<AggregatedStats | null>(null);
  const [loading, setLoading] = useState(false);
  const [fileName, setFileName] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleFileSelect = async (file: File) => {
    setLoading(true);
    setError(null);
    try {
      const parsed = await parseFile(file);
      if (parsed.length === 0) {
        throw new Error("No valid data found in file");
      }
      const aggregated = aggregateData(parsed);
      setData(parsed);
      setStats(aggregated);
      setFileName(file.name);
    } catch (err) {
      setError("Failed to parse file. Please ensure it is a valid CSV or Excel file matching the schema.");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setData(null);
    setStats(null);
    setFileName('');
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 pb-12">
      {/* Navbar */}
      <nav className="bg-white border-b border-slate-200 sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center gap-2">
              <div className="bg-blue-600 p-2 rounded-lg">
                <LayoutDashboard className="w-5 h-5 text-white" />
              </div>
              <span className="font-bold text-xl tracking-tight text-slate-900">InsightStream</span>
            </div>
            <div className="flex items-center">
                <span className="text-xs font-medium px-2 py-1 bg-slate-100 text-slate-500 rounded">
                    Local & Secure
                </span>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {!stats ? (
          <div className="max-w-2xl mx-auto mt-12">
            <div className="text-center mb-10">
              <h1 className="text-3xl font-bold text-slate-900 mb-4">
                Analyze your Sales Performance
              </h1>
              <p className="text-slate-600 text-lg">
                Upload your spreadsheet to generate instant visualizations and AI-powered executive summaries.
              </p>
            </div>
            
            <FileUpload onFileSelect={handleFileSelect} isLoading={loading} />
            
            {error && (
              <div className="mt-6 p-4 bg-red-50 border border-red-200 text-red-700 rounded-lg text-sm text-center">
                {error}
              </div>
            )}

            <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
               <div className="p-4">
                  <h4 className="font-semibold text-slate-800 mb-2">1. Upload</h4>
                  <p className="text-sm text-slate-500">Drag & drop your Excel or CSV sales logs.</p>
               </div>
               <div className="p-4">
                  <h4 className="font-semibold text-slate-800 mb-2">2. Process</h4>
                  <p className="text-sm text-slate-500">Data is processed locally in your browser.</p>
               </div>
               <div className="p-4">
                  <h4 className="font-semibold text-slate-800 mb-2">3. Insight</h4>
                  <p className="text-sm text-slate-500">Get charts and AI summaries instantly.</p>
               </div>
            </div>
          </div>
        ) : (
          <Dashboard stats={stats} fileName={fileName} onReset={handleReset} />
        )}
      </main>
    </div>
  );
};

export default App;