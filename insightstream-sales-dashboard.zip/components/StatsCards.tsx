import React from 'react';
import { AggregatedStats } from '../types';
import { DollarSign, ShoppingBag, TrendingUp, AlertCircle } from 'lucide-react';

const Card = ({ title, value, subtext, icon: Icon, trend }: any) => (
  <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
    <div className="flex justify-between items-start">
      <div>
        <p className="text-sm font-medium text-slate-500">{title}</p>
        <h3 className="text-2xl font-bold text-slate-900 mt-1">{value}</h3>
      </div>
      <div className="p-2 bg-blue-50 rounded-lg">
        <Icon className="w-5 h-5 text-blue-600" />
      </div>
    </div>
    <div className="mt-4 flex items-center text-sm">
      <span className={`font-medium ${trend === 'up' ? 'text-green-600' : 'text-slate-600'}`}>
        {subtext}
      </span>
    </div>
  </div>
);

export const StatsCards: React.FC<{ stats: AggregatedStats }> = ({ stats }) => {
  const formatter = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 0,
  });

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      <Card
        title="Total Revenue"
        value={formatter.format(stats.totalRevenue)}
        subtext={`${stats.totalOrders} total transactions`}
        icon={DollarSign}
        trend="up"
      />
      <Card
        title="Avg Deal Size"
        value={formatter.format(stats.avgDealSize)}
        subtext="Per transaction"
        icon={TrendingUp}
      />
      <Card
        title="Best Category"
        value={stats.topCategories[0]?.name || 'N/A'}
        subtext={`$${formatter.format(stats.topCategories[0]?.value || 0)}`}
        icon={ShoppingBag}
        trend="up"
      />
      <Card
        title="Top Region"
        value={stats.revenueByRegion[0]?.name || 'Global'}
        subtext="Based on volume"
        icon={AlertCircle}
      />
    </div>
  );
};