import React from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import { AggregatedStats, MetricType } from '../types';

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

interface ChartProps {
  stats: AggregatedStats;
  metric: MetricType;
}

export const CategoryChart: React.FC<ChartProps> = ({ stats }) => {
  const data = stats.topSubcategories.slice(0, 8); // Top 8 subcategories

  return (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 h-96">
      <h3 className="text-lg font-semibold text-slate-800 mb-4">Top Revenue by Subcategory</h3>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} layout="vertical" margin={{ left: 40 }}>
          <CartesianGrid strokeDasharray="3 3" horizontal={false} />
          <XAxis type="number" tickFormatter={(v) => `$${(v/1000).toFixed(0)}k`} />
          <YAxis type="category" dataKey="name" width={100} />
          <Tooltip formatter={(v: number) => `$${v.toLocaleString()}`} />
          <Bar dataKey="value" fill="#3b82f6" radius={[0, 4, 4, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

export const RegionChart: React.FC<ChartProps> = ({ stats }) => {
  // If no specific regions found (just 'Global' or 'Unknown'), visual might be boring, but accurate.
  const data = stats.revenueByRegion.slice(0, 6);

  return (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 h-96">
      <h3 className="text-lg font-semibold text-slate-800 mb-4">Performance by Region</h3>
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius={60}
            outerRadius={100}
            fill="#8884d8"
            paddingAngle={5}
            dataKey="value"
          >
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip formatter={(v: number) => `$${v.toLocaleString()}`} />
          <Legend />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
};

export const SalesRepChart: React.FC<ChartProps> = ({ stats }) => {
  const data = stats.salesRepPerformance.slice(0, 10);
  
  return (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 h-96">
      <h3 className="text-lg font-semibold text-slate-800 mb-4">Sales Rep Leaderboard</h3>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" vertical={false} />
          <XAxis dataKey="name" />
          <YAxis tickFormatter={(v) => `$${(v/1000).toFixed(0)}k`} />
          <Tooltip formatter={(v: number) => `$${v.toLocaleString()}`} />
          <Bar dataKey="revenue" fill="#10b981" radius={[4, 4, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

export const TrendChart: React.FC<ChartProps> = ({ stats }) => {
    // Group by month to reduce noise if too many days
    const data = stats.revenueByDate;

    return (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 h-96">
      <h3 className="text-lg font-semibold text-slate-800 mb-4">Revenue Trend</h3>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" vertical={false} />
          <XAxis dataKey="date" minTickGap={30} />
          <YAxis tickFormatter={(v) => `$${(v/1000).toFixed(0)}k`} />
          <Tooltip formatter={(v: number) => `$${v.toLocaleString()}`} />
          <Line type="monotone" dataKey="value" stroke="#8b5cf6" strokeWidth={2} dot={false} />
        </LineChart>
      </ResponsiveContainer>
    </div>
    )
}