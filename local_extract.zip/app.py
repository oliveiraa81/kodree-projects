import os
import re
import io
import pytesseract
import pandas as pd
from PIL import Image
from flask import Flask, render_template, request, send_file, jsonify
from werkzeug.utils import secure_filename

app = Flask(__name__)

# CONFIGURATION
# IMPORTANT: Update this path if Tesseract is installed elsewhere
# Common Windows path: r'C:\Users\andreoliveira\AppData\Local\Programs\Tesseract-OCR\tesseract.exe
# Common Linux/Mac path: '/usr/bin/tesseract'
if os.name == 'nt':
    pytesseract.pytesseract.tesseract_cmd = r'C:\Users\andreoliveira\AppData\Local\Programs\Tesseract-OCR\tesseract.exe'

UPLOAD_FOLDER = 'temp_uploads'
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def safe_extract(pattern, text, group_index=1, default=""):
    """Helper to safely extract regex matches without crashing."""
    try:
        match = re.search(pattern, text, re.IGNORECASE | re.MULTILINE)
        if match:
            return match.group(group_index).strip()
    except Exception:
        pass
    return default

def parse_ocr_text(text):
    """
    Parses raw OCR text into the specific 23 columns defined in the PRD.
    Logic is tailored for Portuguese Transport Orders.
    """
    data = {}
    
    # 1. Data de Carga
    data['Data de Carga'] = safe_extract(r'Data de Carga\s*[:\.]?\s*(\d{2}[-/]\d{2}[-/]\d{4})', text)

    # 2 & 3. Origem (País & Localidade)
    # Looking for: "Local de origem: PT - 47 Jesufrei"
    origem_line = safe_extract(r'Local de origem\s*[:\.]?\s*(.*)', text, 1)
    if origem_line and '-' in origem_line:
        parts = origem_line.split('-', 1)
        data['Origem País'] = parts[0].strip()
        data['Origem Localidade'] = parts[1].strip()
    else:
        data['Origem País'] = ""
        data['Origem Localidade'] = origem_line

    # 4 & 5. Destino (País & Localidade)
    destino_line = safe_extract(r'Local de Destino\s*[:\.]?\s*(.*)', text, 1)
    if destino_line and '-' in destino_line:
        parts = destino_line.split('-', 1)
        data['Destino País'] = parts[0].strip()
        data['Destino Localidade'] = parts[1].strip()
    else:
        data['Destino País'] = ""
        data['Destino Localidade'] = destino_line

    # 6. Peso Bruto (kg) - Extract digits/floats before 'kg'
    data['Peso Bruto (kg)'] = safe_extract(r'Peso bruto\s*[:\.]?\s*([\d\.,\s]+)', text).replace(' ', '')

    # 7. Tipo de Serviço - Extract text inside parentheses in Peso bruto line
    # Ex: Peso bruto: ... (FTL - Carga Completa)
    data['Tipo de Serviço'] = safe_extract(r'Peso bruto.*?\((.*?)\)', text)

    # 8. Quantidade (m estrado)
    data['Quantidade (m estrado)'] = safe_extract(r'Quantidade\s*[:\.]?\s*([\d\.,]+)', text)

    # 9. Tipo de Camião
    data['Tipo de Camião'] = safe_extract(r'(?:Tipo de Camião|Estrutura)\s*[:\.]?\s*(.*)', text)

    # 10. Tipo de Carga / Equipamento
    data['Tipo de Carga'] = safe_extract(r'Equipamento\s*[:\.]?\s*(.*)', text)

    # 11. Data de Descarga (Look inside Observações or general text for "Descarga DD/MM/YYYY")
    data['Data de Descarga'] = safe_extract(r'Descarga\s.*?(\d{2}[-/]\d{2}[-/]\d{4})', text)

    # 12. Janela de Descarga (Look for HHhMM pattern)
    data['Janela de Descarga'] = safe_extract(r'(\d{1,2}h\d{2})', text, 1)

    # 13. Observações (Capture block)
    # Simple strategy: Find header and take next 200 chars or until next header
    obs_match = re.search(r'(?:Observações|Notas Importantes)([\s\S]{1,500})', text, re.IGNORECASE)
    data['Observações'] = obs_match.group(1).strip() if obs_match else ""

    # 14. Instruções Adicionais
    data['Instruções Adicionais'] = safe_extract(r'(?:Instruções|Requisitos)([\s\S]{1,200})', text)

    # 15. Ref / Assunto Email
    data['Ref / Assunto Email'] = safe_extract(r'(?:Ref|Assunto).*?[:\.]?\s*(.*)', text)

    # 16 & 17. Empresa & Morada (REMETENTE Context)
    # Assumes "REMETENTE" is followed by Company on line 1, Address on line 2
    remetente_block = re.search(r'REMETENTE\s*[\n\r]+(.*?)(?:[\n\r]+(.*?))?[\n\r]', text, re.MULTILINE)
    if remetente_block:
        data['Empresa'] = remetente_block.group(1).strip()
        data['Remetente Morada'] = remetente_block.group(2).strip() if remetente_block.group(2) else ""
    else:
        data['Empresa'] = ""
        data['Remetente Morada'] = ""

    # 18. Telefone
    data['Telefone'] = safe_extract(r'(?:Telefone|Telemóvel|Contactos).*?([\+\d\s]{9,})', text)

    # 19. Emails
    data['Emails'] = safe_extract(r'([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9_-]+)', text, 1)

    # 20. Estado da Oportunidade
    data['Estado da Oportunidade'] = ""

    # 21. Valor Estimado
    data['Valor Estimado'] = safe_extract(r'Valor\s*[:\.]?\s*([\d\.,]+)', text)

    # 22. Responsável Interno
    data['Responsável Interno'] = ""

    # 23. Notas Internas
    data['Notas Internas'] = ""

    return data

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400

    if file:
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)

        try:
            # 1. OCR Processing
            image = Image.open(filepath)
            # Portuguese language hint 'por' matches best, but 'eng' usually works for structure
            # If tesseract-por is installed, change lang='por'
            raw_text = pytesseract.image_to_string(image) 
            
            # 2. Parse Data
            parsed_data = parse_ocr_text(raw_text)

            # 3. Create Excel
            df = pd.DataFrame([parsed_data])
            output = io.BytesIO()
            with pd.ExcelWriter(output, engine='openpyxl') as writer:
                df.to_excel(writer, index=False, sheet_name='Extracted Data')
            output.seek(0)

            # Cleanup
            image.close()
            os.remove(filepath)

            return send_file(
                output,
                as_attachment=True,
                download_name=f"extracted_{os.path.splitext(filename)[0]}.xlsx",
                mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
            )

        except Exception as e:
            return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)