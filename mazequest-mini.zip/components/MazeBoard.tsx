import React from 'react';
import { TileType, Entity, ItemType, Position } from '../types';
import { CELL_SIZE } from '../constants';
import { 
  Key, 
  DoorOpen, 
  DoorClosed, 
  Zap, 
  Coins, 
  Diamond, 
  User, 
  LogOut, 
  ToggleLeft, 
  ToggleRight,
  Lock
} from 'lucide-react';

interface MazeBoardProps {
  grid: TileType[][];
  items: Entity[];
  playerPos: Position;
}

const MazeBoard: React.FC<MazeBoardProps> = ({ grid, items, playerPos }) => {
  
  const renderTile = (type: TileType, x: number, y: number) => {
    let bgColor = 'bg-emerald-900'; // Default Floor
    let content = null;

    switch (type) {
      case TileType.WALL:
        return <div key={`${x}-${y}`} className="w-full h-full bg-slate-700 shadow-inner border border-slate-600 rounded-sm" />;
      case TileType.FLOOR:
        bgColor = 'bg-emerald-50/10';
        break;
      case TileType.DOOR_LOCKED:
        bgColor = 'bg-amber-900';
        content = <Lock className="w-5 h-5 text-amber-500" />;
        break;
      case TileType.DOOR_OPEN:
        bgColor = 'bg-emerald-900/50';
        content = <DoorOpen className="w-6 h-6 text-emerald-300 opacity-50" />;
        break;
      case TileType.EXIT_LOCKED:
        bgColor = 'bg-purple-900';
        content = <DoorClosed className="w-6 h-6 text-purple-400" />;
        break;
      case TileType.EXIT_OPEN:
        bgColor = 'bg-purple-500 animate-pulse';
        content = <LogOut className="w-6 h-6 text-white" />;
        break;
      case TileType.TRAP_ACTIVE:
        bgColor = 'bg-red-900/80';
        content = <Zap className="w-5 h-5 text-red-500 animate-pulse" />;
        break;
      case TileType.TRAP_INACTIVE:
        bgColor = 'bg-slate-800';
        content = <div className="w-2 h-2 rounded-full bg-slate-500" />;
        break;
    }

    return (
      <div 
        key={`${x}-${y}`} 
        className={`w-full h-full flex items-center justify-center ${bgColor} transition-colors duration-300 relative`}
      >
        {content}
      </div>
    );
  };

  const renderItem = (item: Entity) => {
    if (item.collected) return null;

    const style = {
      left: item.position.x * CELL_SIZE,
      top: item.position.y * CELL_SIZE,
      width: CELL_SIZE,
      height: CELL_SIZE,
    };

    let icon = null;
    switch (item.type) {
      case ItemType.COIN:
        icon = <Coins className="w-5 h-5 text-yellow-400 animate-bounce" />;
        break;
      case ItemType.GEM:
        icon = <Diamond className="w-5 h-5 text-cyan-400 animate-pulse" />;
        break;
      case ItemType.KEY_RED:
        icon = <Key className="w-5 h-5 text-red-500" />;
        break;
      case ItemType.KEY_BLUE:
        icon = <Key className="w-5 h-5 text-blue-500" />;
        break;
      case ItemType.SWITCH:
        icon = item.active ? 
          <ToggleRight className="w-6 h-6 text-green-400" /> : 
          <ToggleLeft className="w-6 h-6 text-slate-400" />;
        break;
    }

    return (
      <div key={item.id} className="absolute flex items-center justify-center pointer-events-none z-10" style={style}>
        {icon}
      </div>
    );
  };

  // Calculate board dimensions
  const width = grid[0].length * CELL_SIZE;
  const height = grid.length * CELL_SIZE;

  return (
    <div 
      className="relative bg-slate-900 rounded-lg shadow-2xl overflow-hidden border-4 border-slate-800 mx-auto"
      style={{ width, height }}
    >
      {/* Grid Layer */}
      <div 
        className="grid absolute inset-0" 
        style={{ 
          gridTemplateColumns: `repeat(${grid[0].length}, ${CELL_SIZE}px)`,
          gridTemplateRows: `repeat(${grid.length}, ${CELL_SIZE}px)`
        }}
      >
        {grid.map((row, y) => row.map((tile, x) => renderTile(tile, x, y)))}
      </div>

      {/* Items Layer */}
      {items.map(renderItem)}

      {/* Player Layer */}
      <div 
        className="absolute z-20 transition-all duration-200 ease-out flex items-center justify-center"
        style={{
          left: playerPos.x * CELL_SIZE,
          top: playerPos.y * CELL_SIZE,
          width: CELL_SIZE,
          height: CELL_SIZE,
        }}
      >
        <div className="w-3/4 h-3/4 bg-blue-500 rounded-full shadow-lg relative flex items-center justify-center ring-2 ring-white">
          <User className="w-4 h-4 text-white" />
        </div>
      </div>
    </div>
  );
};

export default MazeBoard;
