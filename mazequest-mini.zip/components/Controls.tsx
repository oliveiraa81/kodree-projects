import React from 'react';
import { ArrowUp, ArrowDown, ArrowLeft, ArrowRight } from 'lucide-react';

interface ControlsProps {
  onMove: (dx: number, dy: number) => void;
}

const Controls: React.FC<ControlsProps> = ({ onMove }) => {
  const btnClass = "w-14 h-14 bg-slate-700/80 active:bg-blue-600 rounded-full flex items-center justify-center text-white backdrop-blur-sm shadow-lg border border-slate-500 transition-colors select-none touch-manipulation";

  return (
    <div className="grid grid-cols-3 gap-2 mt-4 max-w-[200px] mx-auto pb-4">
      <div />
      <button 
        className={btnClass} 
        onPointerDown={(e) => { e.preventDefault(); onMove(0, -1); }}
        aria-label="Move Up"
      >
        <ArrowUp className="w-8 h-8" />
      </button>
      <div />
      
      <button 
        className={btnClass} 
        onPointerDown={(e) => { e.preventDefault(); onMove(-1, 0); }}
        aria-label="Move Left"
      >
        <ArrowLeft className="w-8 h-8" />
      </button>
      <div />
      <button 
        className={btnClass} 
        onPointerDown={(e) => { e.preventDefault(); onMove(1, 0); }}
        aria-label="Move Right"
      >
        <ArrowRight className="w-8 h-8" />
      </button>

      <div />
      <button 
        className={btnClass} 
        onPointerDown={(e) => { e.preventDefault(); onMove(0, 1); }}
        aria-label="Move Down"
      >
        <ArrowDown className="w-8 h-8" />
      </button>
      <div />
    </div>
  );
};

export default Controls;
