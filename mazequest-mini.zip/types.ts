export enum GameStatus {
  START = 'START',
  PLAYING = 'PLAYING',
  WON = 'WON',
}

export enum TileType {
  FLOOR = 0,
  WALL = 1,
  DOOR_LOCKED = 2,
  DOOR_OPEN = 3,
  EXIT_LOCKED = 4,
  EXIT_OPEN = 5,
  TRAP_ACTIVE = 6,
  TRAP_INACTIVE = 7,
}

export enum ItemType {
  NONE = 'NONE',
  KEY_RED = 'KEY_RED',
  KEY_BLUE = 'KEY_BLUE',
  COIN = 'COIN',
  GEM = 'GEM',
  SWITCH = 'SWITCH',
}

export interface Position {
  x: number;
  y: number;
}

export interface Entity {
  id: string;
  type: ItemType;
  position: Position;
  collected?: boolean;
  active?: boolean; // For switches
  targetId?: string; // For switches targeting doors
}

export interface GameState {
  status: GameStatus;
  playerPos: Position;
  inventory: ItemType[];
  score: number;
  items: Entity[];
  grid: TileType[][];
  message: string | null;
  startTime: number;
  endTime: number;
}
