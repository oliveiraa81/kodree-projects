import { TileType, ItemType, Entity } from './types';

export const CELL_SIZE = 40; // Pixels
export const GRID_WIDTH = 15;
export const GRID_HEIGHT = 12;

// Map Legend:
// 0: Floor
// 1: Wall
// 2: Door (Red Key)
// 3: Door Open
// 4: Exit Locked
// 5: Exit Open
// 6: Trap Active
// 7: Trap Inactive

export const INITIAL_GRID_LAYOUT = [
  [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
  [1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1],
  [1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1],
  [1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1],
  [1, 0, 1, 1, 1, 2, 1, 0, 1, 1, 1, 1, 1, 0, 1],
  [1, 0, 0, 0, 1, 0, 0, 0, 1, 6, 6, 6, 1, 0, 1],
  [1, 1, 1, 0, 1, 1, 1, 0, 1, 6, 0, 6, 1, 0, 1],
  [1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 2, 1, 1, 0, 1],
  [1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1],
  [1, 0, 1, 4, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 1],
  [1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 1],
  [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
];

export const INITIAL_PLAYER_POS = { x: 1, y: 1 };

export const INITIAL_ITEMS: Entity[] = [
  { id: 'coin-1', type: ItemType.COIN, position: { x: 3, y: 1 } },
  { id: 'coin-2', type: ItemType.COIN, position: { x: 13, y: 1 } },
  { id: 'coin-3', type: ItemType.COIN, position: { x: 1, y: 10 } },
  { id: 'coin-4', type: ItemType.COIN, position: { x: 13, y: 10 } },
  { id: 'gem-1', type: ItemType.GEM, position: { x: 7, y: 3 } }, // Bonus
  { id: 'key-red', type: ItemType.KEY_RED, position: { x: 13, y: 3 } }, // Opens door at (5,4)
  { id: 'key-blue', type: ItemType.KEY_BLUE, position: { x: 1, y: 7 } }, // Opens door at (10,7)
  { id: 'switch-traps', type: ItemType.SWITCH, position: { x: 11, y: 4 }, active: false, targetId: 'traps' },
];

// Target definitions for logic
export const DOOR_RED_POS = { x: 5, y: 4 };
export const DOOR_BLUE_POS = { x: 10, y: 7 };
export const EXIT_POS = { x: 3, y: 9 };
export const REQUIRED_COINS_FOR_EXIT = 4;
