import React, { useState, useEffect, useCallback, useRef } from 'react';
import { GameStatus, GameState, Position, TileType, ItemType, Entity } from './types';
import { 
  INITIAL_GRID_LAYOUT, 
  INITIAL_PLAYER_POS, 
  INITIAL_ITEMS, 
  CELL_SIZE,
  DOOR_RED_POS,
  DOOR_BLUE_POS,
  REQUIRED_COINS_FOR_EXIT
} from './constants';
import MazeBoard from './components/MazeBoard';
import Controls from './components/Controls';
import { Play, RotateCcw, Trophy, Timer, Coins } from 'lucide-react';

const App: React.FC = () => {
  // --- State Initialization ---
  const [gameState, setGameState] = useState<GameState>({
    status: GameStatus.START,
    playerPos: { ...INITIAL_PLAYER_POS },
    inventory: [],
    score: 0,
    items: JSON.parse(JSON.stringify(INITIAL_ITEMS)), // Deep copy
    grid: JSON.parse(JSON.stringify(INITIAL_GRID_LAYOUT)), // Deep copy
    message: null,
    startTime: 0,
    endTime: 0,
  });

  const messageTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // --- Helper Functions ---
  
  const showMessage = (msg: string, duration: number = 2000) => {
    if (messageTimeoutRef.current) clearTimeout(messageTimeoutRef.current);
    setGameState(prev => ({ ...prev, message: msg }));
    messageTimeoutRef.current = setTimeout(() => {
      setGameState(prev => ({ ...prev, message: null }));
    }, duration);
  };

  const startGame = () => {
    setGameState({
      status: GameStatus.PLAYING,
      playerPos: { ...INITIAL_PLAYER_POS },
      inventory: [],
      score: 0,
      items: JSON.parse(JSON.stringify(INITIAL_ITEMS)),
      grid: JSON.parse(JSON.stringify(INITIAL_GRID_LAYOUT)),
      message: "Find the coins to unlock the exit!",
      startTime: Date.now(),
      endTime: 0,
    });
  };

  // --- Game Logic ---

  const checkInteraction = (newPos: Position, currentGrid: TileType[][], currentItems: Entity[], currentInventory: ItemType[]) => {
    let newGrid = [...currentGrid.map(row => [...row])];
    let newItems = [...currentItems];
    let newInventory = [...currentInventory];
    let newScore = gameState.score;
    let msg = gameState.message;
    let status = gameState.status;
    let finalPos = { ...newPos };

    // 1. Check Tile Interaction
    const tile = newGrid[newPos.y][newPos.x];

    // Block Movement
    if (tile === TileType.WALL) return null;
    
    // Doors
    if (tile === TileType.DOOR_LOCKED) {
      // Logic for Red Door
      if (newPos.x === DOOR_RED_POS.x && newPos.y === DOOR_RED_POS.y) {
        if (newInventory.includes(ItemType.KEY_RED)) {
          newGrid[newPos.y][newPos.x] = TileType.DOOR_OPEN;
          msg = "Red Door Unlocked!";
        } else {
          showMessage("Locked! Need Red Key.");
          return null;
        }
      }
      // Logic for Blue Door
      else if (newPos.x === DOOR_BLUE_POS.x && newPos.y === DOOR_BLUE_POS.y) {
         if (newInventory.includes(ItemType.KEY_BLUE)) {
          newGrid[newPos.y][newPos.x] = TileType.DOOR_OPEN;
          msg = "Blue Door Unlocked!";
        } else {
           showMessage("Locked! Need Blue Key.");
          return null;
        }
      } else {
        showMessage("Locked!");
        return null;
      }
    }

    // Traps
    if (tile === TileType.TRAP_ACTIVE) {
      showMessage("Ouch! A Trap!");
      // Push back or reset? Let's push back to previous pos for MVP simplicity
      // Or just return null effectively blocking movement into the trap (but simpler: allow move then hurt?)
      // Design decision: Block movement into spikes with message
      showMessage("It's too dangerous!");
      return null; 
    }

    // Exit
    if (tile === TileType.EXIT_LOCKED) {
      const coins = newInventory.filter(i => i === ItemType.COIN).length;
      if (coins >= REQUIRED_COINS_FOR_EXIT) {
        newGrid[newPos.y][newPos.x] = TileType.EXIT_OPEN;
        msg = "Exit Unlocked! You can leave now.";
        // Don't move INTO the locked door tile this turn, just unlock it
        // The user has to press again to enter
        // Actually, let's unlock immediately if they bump it
        return { 
          newGrid, newItems, newInventory, newScore, msg, status, 
          finalPos: gameState.playerPos // Stay put, just unlocked
        };
      } else {
        showMessage(`Need ${REQUIRED_COINS_FOR_EXIT - coins} more coins!`);
        return null;
      }
    }

    if (tile === TileType.EXIT_OPEN) {
      status = GameStatus.WON;
      msg = "LEVEL COMPLETE!";
    }

    // 2. Check Item Interaction
    // Find item at new position
    const itemIndex = newItems.findIndex(
      i => !i.collected && i.position.x === newPos.x && i.position.y === newPos.y
    );

    if (itemIndex !== -1) {
      const item = newItems[itemIndex];
      
      if (item.type === ItemType.SWITCH) {
        // Toggle Switch
        newItems[itemIndex] = { ...item, active: !item.active };
        msg = "Switch toggled!";
        
        // Hardcoded Logic for Switch -> Traps
        if (item.targetId === 'traps') {
           const trapActive = !item.active; // If switch is active, traps are off (inactive)
           // Iterate grid to find traps
           newGrid = newGrid.map(row => row.map(cell => {
             if (cell === TileType.TRAP_ACTIVE && trapActive) return TileType.TRAP_INACTIVE;
             if (cell === TileType.TRAP_INACTIVE && !trapActive) return TileType.TRAP_ACTIVE;
             return cell;
           }));
           msg = trapActive ? "Traps Deactivated!" : "Traps Activated!";
        }
      } else {
        // Collect Item
        newItems[itemIndex] = { ...item, collected: true };
        newInventory.push(item.type);
        
        if (item.type === ItemType.COIN) {
          newScore += 100;
          msg = "Coin collected!";
        } else if (item.type === ItemType.GEM) {
          newScore += 500;
          msg = "Gem found! +500pts";
        } else if (item.type.includes('KEY')) {
          msg = "Key collected!";
        }
      }
    }

    return { newGrid, newItems, newInventory, newScore, msg, status, finalPos };
  };

  const movePlayer = useCallback((dx: number, dy: number) => {
    if (gameState.status !== GameStatus.PLAYING) return;

    const { x, y } = gameState.playerPos;
    const newPos = { x: x + dx, y: y + dy };

    // Bounds check
    if (newPos.y < 0 || newPos.y >= gameState.grid.length || newPos.x < 0 || newPos.x >= gameState.grid[0].length) {
      return;
    }

    const result = checkInteraction(newPos, gameState.grid, gameState.items, gameState.inventory);

    if (result) {
      setGameState(prev => {
        // If winning, set end time
        const endTime = result.status === GameStatus.WON ? Date.now() : 0;
        
        if (result.msg && result.msg !== prev.message) {
          showMessage(result.msg, 1500);
        }

        return {
          ...prev,
          playerPos: result.finalPos,
          grid: result.newGrid,
          items: result.newItems,
          inventory: result.newInventory,
          score: result.newScore,
          status: result.status,
          endTime: endTime || prev.endTime
        };
      });
    }
  }, [gameState.status, gameState.grid, gameState.items, gameState.inventory, gameState.playerPos, gameState.score]);

  // --- Keyboard Input ---
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      switch (e.key) {
        case 'ArrowUp': case 'w': case 'W': movePlayer(0, -1); break;
        case 'ArrowDown': case 's': case 'S': movePlayer(0, 1); break;
        case 'ArrowLeft': case 'a': case 'A': movePlayer(-1, 0); break;
        case 'ArrowRight': case 'd': case 'D': movePlayer(1, 0); break;
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [movePlayer]);

  // --- Render Helpers ---
  const formatTime = (start: number, end: number) => {
    const diff = (end || Date.now()) - start;
    const seconds = Math.floor(diff / 1000);
    return `${Math.floor(seconds / 60)}:${(seconds % 60).toString().padStart(2, '0')}`;
  };

  const [timerStr, setTimerStr] = useState("0:00");
  useEffect(() => {
    if (gameState.status === GameStatus.PLAYING) {
      const interval = setInterval(() => {
        setTimerStr(formatTime(gameState.startTime, 0));
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [gameState.status, gameState.startTime]);


  return (
    <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center p-4 font-sans text-slate-100">
      
      <div className="w-full max-w-xl flex flex-col gap-4">
        
        {/* Header / HUD */}
        <div className="flex justify-between items-center bg-slate-800 p-4 rounded-xl shadow-lg border border-slate-700">
          <div className="flex flex-col">
             <h1 className="text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-cyan-400">
              MazeQuest Mini
            </h1>
            <div className="flex items-center gap-2 text-slate-400 text-sm">
              <Timer className="w-4 h-4" />
              <span>{gameState.status === GameStatus.WON ? formatTime(gameState.startTime, gameState.endTime) : timerStr}</span>
            </div>
          </div>

          <div className="flex items-center gap-6">
             <div className="flex flex-col items-end">
                <span className="text-xs text-slate-400 uppercase tracking-wider">Score</span>
                <span className="text-lg font-mono text-yellow-400">{gameState.score}</span>
             </div>
             <div className="flex flex-col items-end">
                <span className="text-xs text-slate-400 uppercase tracking-wider">Coins</span>
                <div className="flex items-center gap-1">
                  <Coins className="w-4 h-4 text-yellow-500" />
                  <span className="text-lg font-mono">
                    {gameState.inventory.filter(i => i === ItemType.COIN).length}/{REQUIRED_COINS_FOR_EXIT}
                  </span>
                </div>
             </div>
          </div>
        </div>

        {/* Message Toast */}
        <div className={`h-8 flex justify-center items-center transition-opacity duration-300 ${gameState.message ? 'opacity-100' : 'opacity-0'}`}>
           <span className="bg-slate-800 text-cyan-300 px-4 py-1 rounded-full text-sm font-semibold border border-cyan-800 shadow-lg">
             {gameState.message || "..."}
           </span>
        </div>

        {/* Game Area */}
        <div className="relative flex justify-center">
          {gameState.status === GameStatus.START && (
            <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-slate-900/90 rounded-lg backdrop-blur-sm p-6 text-center">
              <Trophy className="w-16 h-16 text-yellow-500 mb-4 animate-bounce" />
              <h2 className="text-3xl font-bold text-white mb-2">Ready to Quest?</h2>
              <p className="text-slate-300 mb-6 max-w-xs">
                Collect {REQUIRED_COINS_FOR_EXIT} coins to unlock the exit. Watch out for traps and find keys!
              </p>
              <button 
                onClick={startGame}
                className="flex items-center gap-2 px-8 py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-full transition-all transform hover:scale-105 shadow-lg shadow-emerald-900/50"
              >
                <Play className="w-5 h-5" /> Start Adventure
              </button>
            </div>
          )}

          {gameState.status === GameStatus.WON && (
            <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-emerald-900/95 rounded-lg backdrop-blur-sm p-6 text-center border-2 border-emerald-500">
              <Trophy className="w-20 h-20 text-yellow-300 mb-4 animate-pulse" />
              <h2 className="text-4xl font-bold text-white mb-2">Victory!</h2>
              <div className="bg-slate-800/50 p-4 rounded-lg mb-6 w-full max-w-xs">
                <div className="flex justify-between mb-2">
                  <span className="text-slate-300">Final Score</span>
                  <span className="font-mono text-yellow-400 font-bold">{gameState.score}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-300">Time</span>
                  <span className="font-mono text-white font-bold">{formatTime(gameState.startTime, gameState.endTime)}</span>
                </div>
              </div>
              <button 
                onClick={startGame}
                className="flex items-center gap-2 px-8 py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-full transition-all transform hover:scale-105 shadow-lg"
              >
                <RotateCcw className="w-5 h-5" /> Play Again
              </button>
            </div>
          )}

          <MazeBoard 
            grid={gameState.grid} 
            items={gameState.items} 
            playerPos={gameState.playerPos} 
          />
        </div>

        {/* Mobile Controls */}
        <div className="lg:hidden">
          <Controls onMove={movePlayer} />
        </div>

        {/* Instructions Footer */}
        <div className="text-center text-slate-500 text-xs mt-2">
          <p className="hidden lg:block">Use Arrow Keys or WASD to Move</p>
          <p className="lg:hidden">Tap directional buttons to Move</p>
        </div>

      </div>
    </div>
  );
};

export default App;